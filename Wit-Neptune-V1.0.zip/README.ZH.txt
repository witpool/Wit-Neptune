﻿Wit-Neptune是由WitPool.org个人组织所开发的一个基于Spring Boot的RESTful API示例。

麻雀虽小，但五脏俱全，小小的代码示例涵盖了RESTful API后台的基本功能。

可在这个基础上快速构建后台的能力。

源码的作者靠写代码谋生，如果需要完整源代码请邮件联系作者。

谢谢您对WitPool.org组织的支持与厚爱！

*****************************************
Author:  Dom Wang
Email:   witpool@outlook.com
*****************************************
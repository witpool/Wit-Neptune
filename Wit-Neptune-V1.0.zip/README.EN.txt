﻿Wit-Neptune is developed by personal organization WitPool.org. 

It is a RESTful API demo based on Spring Boot.

Small as the demo is, it possesses all its basic capabilities of the RESTful API server.

Based on this demo, you can quickly build the capabilities of the RESTful API server.

The author is now coding for a living. 

If you want to get the full source code, please contact the author by e-mail.

Thank you for your support for the WitPool.org organization!

*****************************************
Author:  Dom Wang
Email:   witpool@outlook.com
*****************************************
